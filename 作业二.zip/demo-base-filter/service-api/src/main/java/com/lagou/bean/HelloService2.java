package com.lagou.bean;

public interface HelloService2 {
    public String sayHello2(String name, int timeToWait);
}

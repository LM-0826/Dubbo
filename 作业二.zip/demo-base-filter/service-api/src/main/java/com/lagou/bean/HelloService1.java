package com.lagou.bean;

public interface HelloService1 {
    public String sayHello1(String name, int timeToWait);
}

package com.lagou.bean;

public interface HelloService3 {
    public String sayHello3(String name, int timeToWait);
}

package com.lagou.bean.impl;

import com.lagou.bean.HelloService3;
import org.apache.dubbo.config.annotation.Service;

import java.util.Random;

@Service
public class HelloServiceImpl3 implements HelloService3 {

    @Override
    public String sayHello3(String name, int timeToWait) {
        try {
            Thread.sleep(new Random().nextInt(100));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("3");
        return "hello:" + name;
    }
}

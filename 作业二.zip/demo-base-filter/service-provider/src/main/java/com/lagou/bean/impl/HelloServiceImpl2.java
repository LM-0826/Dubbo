package com.lagou.bean.impl;

import com.lagou.bean.HelloService2;
import org.apache.dubbo.config.annotation.Service;

import java.util.Random;

@Service
public class HelloServiceImpl2 implements HelloService2 {

    @Override
    public String sayHello2(String name, int timeToWait) {
        try {
            Thread.sleep(new Random().nextInt(100));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("2");
        return "hello:" + name;
    }
}

package com.lagou.bean.impl;

import com.lagou.bean.HelloService1;
import org.apache.dubbo.config.annotation.Service;

import java.util.Random;

@Service
public class HelloServiceImpl1 implements HelloService1 {

    @Override
    public String sayHello1(String name, int timeToWait) {
        try {
            Thread.sleep(new Random().nextInt(100));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("1");
        return "hello:" + name;
    }
}

import com.lagou.bean.ConsumerComponent;
import com.lagou.thread.RequestThread;
import org.apache.dubbo.config.spring.context.annotation.EnableDubbo;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import java.io.IOException;


public class AnnotationConsumerMain {

    public static void main(String[] args) throws IOException, InterruptedException {

        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(ConsumerConfiguration.class);
        context.start();
        ConsumerComponent service = context.getBean(ConsumerComponent.class);

        // 线程池一直请求dubbo
        RequestThread requestThread1 = new RequestThread();
        requestThread1.init(service);
        requestThread1.Start();

        // 每隔5秒打印
//        new RpcTimeUsedThread().start();



        System.in.read();

    }


    @Configuration
    @PropertySource("classpath:/dubbo-consumer.properties")
    //@EnableDubbo(scanBasePackages = "com.lagou.bean")
    @ComponentScan("com.lagou.bean")
    @EnableDubbo
    static class ConsumerConfiguration {

    }


}

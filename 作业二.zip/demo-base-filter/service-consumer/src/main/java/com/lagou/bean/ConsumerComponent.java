package com.lagou.bean;

import org.apache.dubbo.config.annotation.Reference;
import org.springframework.stereotype.Component;

@Component
public class ConsumerComponent {

    @Reference
    private HelloService1 helloService1;
    @Reference
    private HelloService2 helloService2;
    @Reference
    private HelloService3 helloService3;

    public void sayHello(String name, int timeToWait) {
        helloService1.sayHello1(name, timeToWait);
        helloService2.sayHello2(name, timeToWait);
        helloService3.sayHello3(name, timeToWait);
    }

}

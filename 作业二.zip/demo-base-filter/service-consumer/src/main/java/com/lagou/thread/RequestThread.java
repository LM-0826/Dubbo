package com.lagou.thread;

import com.lagou.bean.ConsumerComponent;
import com.lagou.dto.RpcTimeUsedDTO;
import com.lagou.dto.RpcTimeUsedMap;
import org.springframework.stereotype.Component;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

@Component
public class RequestThread {

    private ConsumerComponent service;

    public void init(ConsumerComponent service) {
        this.service = service;
    }

    public void Start() throws InterruptedException {

        // 开一个线程池，一直调用dubbo,保证一分钟2000以上
        ExecutorService fixedThreadPool = Executors.newFixedThreadPool(50);

        fixedThreadPool.execute(new RpcTimeUsedRunner());


        while (true) {
            for (int i = 0; i < 100; i++) {
                fixedThreadPool.execute(new RequestRunnable());
            }
            Thread.sleep(1000);
        }

    }

    class RequestRunnable extends Thread {

        @Override
        public void run() {
            service.sayHello("test", 0);
//            System.out.println("请求成功");
        }
    }




    class RpcTimeUsedRunner extends Thread {
        @Override
        public void run() {
            while (true) {
                // 首先，把一分钟以前的去掉
                Map<String, List<RpcTimeUsedDTO>> map = RpcTimeUsedMap.remove(System.currentTimeMillis());

                // 得到每个方法的耗时集合
                for (Map.Entry<String, List<RpcTimeUsedDTO>> entry : map.entrySet()) {
                    List<RpcTimeUsedDTO> list = entry.getValue();
                    // 然后把这一分钟耗时的集合按照耗时时间排序
                    list = list.stream().sorted(Comparator.comparing(RpcTimeUsedDTO::getUsedMileTime)).collect(Collectors.toList());
                    // 得到一分钟调用的所有次数，计算，tp90，tp99，打印出来
                    int size = list.size();
                    int tp90 = (int) Math.ceil(size * 0.90) - 1;
                    int tp99 = (int) Math.ceil(size * 0.99) - 1;

                    RpcTimeUsedDTO tp90RpcTimeUsedDTO = list.get(tp90);
                    RpcTimeUsedDTO tp99RpcTimeUsedDTO = list.get(tp99);

                    System.out.println("方法:" + entry.getKey() + ",tp90耗时情况:" + tp90RpcTimeUsedDTO.getUsedMileTime());
                    System.out.println("方法:" + entry.getKey() + ",tp99耗时情况:" + tp99RpcTimeUsedDTO.getUsedMileTime());
                }


                try {
                    // 休息5秒
                    Thread.sleep(5000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

            }


        }


    }




}
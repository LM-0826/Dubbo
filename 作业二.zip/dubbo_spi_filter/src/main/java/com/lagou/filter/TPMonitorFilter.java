package com.lagou.filter;

import com.lagou.dto.RpcTimeUsedDTO;
import com.lagou.dto.RpcTimeUsedMap;
import org.apache.dubbo.common.constants.CommonConstants;
import org.apache.dubbo.common.extension.Activate;
import org.apache.dubbo.rpc.*;


@Activate(group = {CommonConstants.CONSUMER})
public class TPMonitorFilter implements Filter {

    @Override
    public Result invoke(Invoker<?> invoker, Invocation invocation) throws RpcException {
        // 开始时间
        long start = System.currentTimeMillis();
        // 执行逻辑
        Result invoke = invoker.invoke(invocation);
        // 结束时间
        long end = System.currentTimeMillis();
        // 耗时
        long mils = end - start;
        // 调用方法名
        String methodName = invoker.getUrl().getPath();

        // 将每次dubbo调用耗费时间放到集合中
        RpcTimeUsedDTO rpcTimeUsedDTO = new RpcTimeUsedDTO();
        rpcTimeUsedDTO.setStartMileTime(start);
        rpcTimeUsedDTO.setUsedMileTime(mils);

        RpcTimeUsedMap.add(methodName, rpcTimeUsedDTO);

        return invoke;
    }




}

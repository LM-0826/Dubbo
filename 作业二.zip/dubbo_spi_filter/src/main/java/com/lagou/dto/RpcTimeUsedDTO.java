package com.lagou.dto;

public class RpcTimeUsedDTO {

    private Long StartMileTime;

    private Long UsedMileTime;


    public Long getStartMileTime() {
        return StartMileTime;
    }

    public void setStartMileTime(Long startMileTime) {
        StartMileTime = startMileTime;
    }

    public Long getUsedMileTime() {
        return UsedMileTime;
    }

    public void setUsedMileTime(Long usedMileTime) {
        UsedMileTime = usedMileTime;
    }


}

package com.lagou.dto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class RpcTimeUsedMap {

    public static volatile Map<String, List<RpcTimeUsedDTO>> rpcUsedTimeDTOListMap = new HashMap();

    // 根据方法名，新增耗时情况到不同的集合中
    public static void add(String methodName, RpcTimeUsedDTO rpcTimeUsedDTO) {
        synchronized (rpcUsedTimeDTOListMap) {
            List<RpcTimeUsedDTO> list = rpcUsedTimeDTOListMap.get(methodName);
            if (list == null) {
                list = new ArrayList<>();
            }
            list.add(rpcTimeUsedDTO);
            rpcUsedTimeDTOListMap.put(methodName, list);
        }
    }


    // 每个方法中，去掉一分钟以前的数据
    public static Map<String, List<RpcTimeUsedDTO>> remove(Long currentMils) {
        Map<String, List<RpcTimeUsedDTO>> map = new HashMap();

        synchronized (rpcUsedTimeDTOListMap) {
            for (Map.Entry<String, List<RpcTimeUsedDTO>> entry : rpcUsedTimeDTOListMap.entrySet()) {
                List<RpcTimeUsedDTO> rpcTimeUsedDTOList = entry.getValue();

                // 只保留一分钟以内的
                List<RpcTimeUsedDTO> list = rpcTimeUsedDTOList.stream()
                        .filter(rpcTimeUsedDTO -> {
                            return currentMils - rpcTimeUsedDTO.getStartMileTime() < 60000;
                        })
                        .collect(Collectors.toList());

                rpcUsedTimeDTOListMap.put(entry.getKey(), list);

                map.put(entry.getKey(), list);
            }

            // 返回
            return map;
        }
    }


}

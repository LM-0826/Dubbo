package com.lagou.filter;

import com.lagou.util.RequestUtil;
import org.apache.dubbo.common.constants.CommonConstants;
import org.apache.dubbo.common.extension.Activate;
import org.apache.dubbo.rpc.*;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;


@Activate(group = {CommonConstants.CONSUMER})
public class TransportIPFilterC implements Filter {
    @Override
    public Result invoke(Invoker<?> invoker, Invocation invocation) throws RpcException {

        HttpServletRequest currentRequest = RequestUtil.getCurrentRequest();
        String ip = currentRequest.getRemoteAddr();
//        String ip = "jhgkj";

        Map<String, String> context = new HashMap<>();
        //放置ip
        context.put("ip", ip);
        RpcContext.getContext().setAttachments(context);
        return invoker.invoke(invocation);


    }


}

